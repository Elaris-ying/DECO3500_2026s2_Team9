# Gallery Echoes · Netlify 手机入口与可选实体灯

公开入口：https://gallery-echoes-mobile.netlify.app/

访客无需登录，也不需要先连设备 Wi-Fi。主码见 mobile-qr/gallery-echoes-netlify-qr.png，打印卡见 mobile-qr/scan-card.html。
需要控制实体灯时，在 Colour studio 选择颜色 → Connect a wristband → 手机加入 GalleryEchoes（无密码）→ 返回页面 Open wristband controls → Connect your light。

已有 1.4.0 固件无需因换平台重新 Upload。本包保留与已完成 SDK 编译文件一致的 .ino 和 mobile_assets.h；首次安装或旧版升级需两文件同目录，通过 Arduino IDE 上传。
详细使用见 MOBILE-SETUP.md；Netlify 站点维护见 NETLIFY-SETUP.md。此交付包不含完整可编辑网页源码，源码仍在原项目中。
40 个公开应用文件与二维码独立解码均已核验。尚未替用户进行真实手机扫码或实体灯现场联调。
