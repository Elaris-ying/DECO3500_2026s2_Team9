# 连上手环后，如何回到画廊

## 继续看板子里的画廊，无需互联网

在设备调色页点击顶部中文 **返回画廊**，或底部同名按钮。它直接回到 `192.168.4.1` 的完整板载画廊首页，不依赖浏览器后退，也不用离开 **GalleryEchoes** 热点。

返回会保留当时的颜色、亮度和开关，停止演示，不断开当前控灯连接。即使演示正处于全灭帧，返回也不会自动开灯。普通 **Stop sequence** 仍保留“恢复演示前设置”的原有行为。

原生 `/controller` 备用测试页也有 **Back to gallery / 返回画廊** 本地链接。

## 回到原来的在线访问

在线页点击 **Open wristband controls** 会在新标签页打开板子，原画廊标签页会保留。打开浏览器标签页列表，切回原来的 **Gallery Echoes** 即可。

如果需要重新加载在线页面，或点击设备页的 **返回在线画廊**，先切回手机流量或普通 Wi-Fi。公网入口仍为 [gallery-echoes-mobile.netlify.app](https://gallery-echoes-mobile.netlify.app/)，**二维码不变，不必重印已有 Netlify 码**。在线 Echo 和浏览记录归在线域名，板载访问记录不会自动同步过去。

## 看不到板载新按钮

需要把 [1.4.1 交付包](E:/UQ/figma/deliverables/Gallery-Echoes-Mobile-Netlify-1.4.1.zip) 中的新版 `.ino` 和同目录 `mobile_assets.h` 一起 USB Upload 到 Nano ESP32。**板子已有 1.4.0 也要升级一次；仅刷新公网网页不会更新板子。**

上传后重新加入 GalleryEchoes（无密码），查看 `http://192.168.4.1/controller`，应显示 **Firmware 1.4.1**。具体上传步骤见 [MOBILE-SETUP.md](E:/UQ/figma/MOBILE-SETUP.md)。

本说明描述新版交互；实际 SDK 编译、公网部署与公开访问结果见对应当前报告。尚未替用户完成 USB 上传、手机实扫或实体灯现场验证。
