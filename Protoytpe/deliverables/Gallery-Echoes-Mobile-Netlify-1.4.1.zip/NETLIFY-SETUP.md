# Gallery Echoes · Netlify 正式部署

正式公开入口：[https://gallery-echoes-mobile.netlify.app/](https://gallery-echoes-mobile.netlify.app/)。当前使用 **Netlify Free**，任何访客无需登录，使用手机流量或普通 Wi-Fi 即可浏览完整原型。

1.4.1 更新增加返回入口：设备调色页顶部和底部的 **返回画廊** 进入同源板载首页，即使 GalleryEchoes 热点没有互联网也能继续看展；返回保留当前颜色、亮度、开关并停止演示，不断开控灯连接。另有 **返回在线画廊** 外链，需要手机流量或普通 Wi-Fi。在线和板载访问记录仍分别属于各自域名。

在线 **Open wristband controls** 改为在新标签页打开板子，保留原在线画廊，可直接切回。**已有 1.4.0 的板子也必须上传 1.4.1 新版 .ino 与同目录 mobile_assets.h 一次才能看到板载按钮；仅部署或刷新 Netlify 不会更新固件。**普通 Stop sequence 仍恢复原设置，原生 `/controller` 也有返回板载画廊入口。

## 当前站点与验证

- Site ID：`6af768ac-2500-4d87-9cd9-fefba8517b39`
- 当前 Production Deploy ID：见 `deliverables/netlify-deployment.json` 当前报告；每次重新发布的 Deploy ID 不同，不将旧版 ID 当作 1.4.1 发布结果。
- 正式 URL：`https://gallery-echoes-mobile.netlify.app/`
- 发布目录：`netlify-site/dist`，其顶层包含 `index.html`。
- 配置：`netlify-site/netlify.toml` 使用 `publish = "dist"`、空构建命令；无需 SPA 全路径回退。
- 当前公开访问证据：[deliverables/netlify-public-verification.json](E:/UQ/figma/deliverables/netlify-public-verification.json)，结果和资源容量以本次重新部署后的报告为准。校验对全部 **40 个应用文件**发起无登录请求，39 个非 HTML 资源的原始响应大小与 SHA-256 直接匹配发布包。HTML 响应包含 Netlify 在边缘注入的站点说明与 public 徽章；验证脚本只移除这两段完整、逐字匹配的本站注入块后再与发布文件比对，同时校验根入口与查询参数入口。报告另保留原始响应的大小与 SHA-256，不声称原始 HTML 响应和发布文件逐字节相同。

这些检查验证公开静态访问，不代表已完成手机扫码、触屏布局、浏览器权限或实体灯联调。完整 24 屏及交接逻辑另有本地软件检查。

## 二维码与交付

- [Netlify 主二维码](E:/UQ/figma/mobile-qr/gallery-echoes-netlify-qr.png) 指向上述正式公网地址；**1.4.1 URL 不变，无需更换已有 Netlify 码**。
- [GalleryEchoes 入网码](E:/UQ/figma/mobile-qr/gallery-echoes-wifi-qr.png) 与本地控灯码用途不变，只在主动使用实体灯时需要。
- 新手机交付包：`deliverables/Gallery-Echoes-Mobile-Netlify-1.4.1.zip`。
- 旧的 1.4.0 交付包保留为历史文件。
- [连接后返回画廊的简短步骤](E:/UQ/figma/RETURN-TO-GALLERY.md)。
- 全部 5 个 PNG 二维码已由独立 jsQR 1.4.0 解码并核对载荷，证据在 `mobile-qr/independent-decode.json`；尚未完成真实手机现场扫码。

## 后续更新同一个站点

1. 在项目中修改并构建、完成相应软件检查，重新生成在线静态产物。`scripts/export-netlify.mjs` 只读取已经验证的 `online-site/dist`，生成独立 `netlify-site/dist`，不会自行构建或部署，也不覆盖本文的现场部署记录。
2. 核对 `netlify-site/package-manifest.json`，确保静态包中的应用文件与源产物一致。使用预构建目录手动上传时，不需要构建命令。
3. 在 Netlify 打开 **现有 Gallery Echoes 项目**，确认 Site ID 仍为 `6af768ac-2500-4d87-9cd9-fefba8517b39`，将 `netlify-site/dist` 部署到同一站点的 Production。使用 CLI 或 API 时同样指定这个 Site ID。**无需新建站点。**
4. 保持公开访问且不启用登录或密码拦截，再运行：

   ```powershell
   node scripts/verify-netlify-deployment.mjs https://gallery-echoes-mobile.netlify.app/
   ```

5. 确认退出码成功和新验证报告后，记录新的 Deploy ID。Site ID 与正式 URL 保持不变；同网址的内容更新不需要重新生成 QR。

包的导出不意味着线上站点已经更新。认证令牌等凭据不得写入源码或交付包。

Netlify 官方操作说明：[Create deploys](https://docs.netlify.com/deploy/create-deploys/)。

## English

The production gallery is **https://gallery-echoes-mobile.netlify.app/**, hosted on **Netlify Free** and accessible to visitors without login. Use the current deployment and public-verification reports for the 1.4.1 release result. Verification requests all 40 files without authentication, compares 39 non-HTML responses directly, and removes only two exact, site-specific Netlify additions before comparing HTML. This does not replace phone interaction or physical light testing.

For future releases, deploy the prebuilt `netlify-site/dist` folder to the **same site**, ID `6af768ac-2500-4d87-9cd9-fefba8517b39`; do not create another site. Verify the new deployment and update its report. The public URL and QR remain unchanged for 1.4.1.

Physical light control remains optional. The board opens in a new tab, keeping the online gallery available. In firmware 1.4.1, **返回画廊** returns to the local board-hosted gallery without internet and preserves the current light settings while stopping the demo. The separate online-gallery link needs internet. **Boards running 1.4.0 must upload the new 1.4.1 .ino and mobile_assets.h once to receive the board's new return buttons.** Refreshing Netlify does not update the board.
