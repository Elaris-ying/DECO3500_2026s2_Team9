# Gallery Echoes · Netlify 手机入口与可选实体灯

公开入口：https://gallery-echoes-mobile.netlify.app/

访客无需登录，也不需要先连设备 Wi-Fi。主码见 mobile-qr/gallery-echoes-netlify-qr.png，打印卡见 mobile-qr/scan-card.html。
需要控制实体灯时，在 Colour studio 选择颜色 → Connect a wristband → 手机加入 GalleryEchoes（无密码）→ 返回页面 Open wristband controls → Connect your light。

当前板载版本为 1.4.1。设备页顶部“返回画廊”可在设备 Wi-Fi 下回到完整画廊；在线画廊会保留在原标签页。旧版设备需要将 .ino 和 mobile_assets.h 放在同一目录，通过 Arduino IDE Upload 一次才能显示新按钮，仅刷新网站不能更新板子。
返回前会保留当前灯色、亮度和开关并停下演示。若要回到在线访问记录，可回原画廊标签页，或恢复互联网后选择“返回在线画廊”。公开网址与二维码不变。
详细使用见 MOBILE-SETUP.md；Netlify 站点维护见 NETLIFY-SETUP.md。此交付包不含完整可编辑网页源码，源码仍在原项目中。
40 个公开应用文件与二维码独立解码均已核验。尚未替用户进行真实手机扫码或实体灯现场联调。
