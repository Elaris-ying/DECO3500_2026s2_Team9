# Gallery Echoes · 在线扫码与可选实体控灯

## 不连接单片机也能打开

正式公开入口：[Gallery Echoes](https://gallery-echoes-mobile.netlify.app/)，当前使用 **Netlify Free** 托管。

任何访客用手机流量或普通 Wi-Fi 都能打开，不需要登录，也不需要连接 GalleryEchoes。扫描 [Netlify 主二维码](E:/UQ/figma/mobile-qr/gallery-echoes-netlify-qr.png) 可进入完整 24 页原型，浏览作品、填写 Echo、查看收藏和预览颜色。

1.4.1 的公开 URL 不变，**已有 Netlify 主二维码无需更换**。只有更早的旧公网入口码或把 192.168.4.1 当作公开主入口的旧码需要替换。入网码和本地控灯码仍各自保持原用途。

## 只有实体变色时才切换 Wi-Fi

1. 在在线原型的 Colour studio 选择颜色、亮度和开关，手环预览与界面即时呼应。
2. 点击 **Connect a wristband**，展开实体灯连接步骤。
3. 打开手机系统 Wi-Fi 设置，连接 **GalleryEchoes**，无密码。无互联网提示时保持此连接。
4. 回到刚才的网页，点击 **Open wristband controls**。它会在**新标签页**打开板载调色面板，并带上已选颜色、亮度及电源状态；原在线画廊标签页会保留。
5. 在板载面板点击 **Connect your light** 后才真正发送，后续调色和亮度直接作用于实体 RGB 灯。黑色或亮度 0 表示关灯。

浏览在线画廊、拖动色盘和预览不会自动请求私网、切换手机 Wi-Fi、跳转或开灯。在线 HTTPS 页面通过用户主动的普通页面导航进入设备 HTTP 页面，避免把私网 HTTP 请求直接嵌入在线站点；没有关闭浏览器安全保护。

## 连接后返回画廊

在设备调色页顶部点击中文 **返回画廊**，或使用底部同名按钮，即可回到 **192.168.4.1 的板载画廊首页**。它不依赖浏览器后退历史，不需要互联网；保持 GalleryEchoes 连接和板子供电即可继续浏览完整画廊。

调色页顶部和底部返回会保留当前颜色、亮度与开关，并将演示停在当前帧；不会因返回而开灯、关灯或断开当前控灯连接。普通 **Stop sequence** 仍恢复演示前的设置。原生 `/controller` 备用页也提供 **Back to gallery / 返回画廊** 本地入口。

若想回到原来的在线访问，可切换到保留的画廊标签页；需要重新联网加载时，先恢复手机流量或普通 Wi-Fi。设备页的 **返回在线画廊** 外链同样需要可访问公网的网络。线上和板载页面各有独立的浏览器存储，在线感想和浏览记录仍归在线域名；交接只传递灯色、亮度和电源，不上传作品感受或个人资料。简短操作见 [RETURN-TO-GALLERY.md](E:/UQ/figma/RETURN-TO-GALLERY.md)。

## 将板子升级至 1.4.1

**已安装 1.4.0 的设备也必须 USB 上传新版 .ino 和同目录 mobile_assets.h 一次，才能看到板载返回按钮。仅刷新 Netlify 网页不能更新板子。**单纯浏览公开原型不需要上传固件。新版交付包为 [Gallery-Echoes-Mobile-Netlify-1.4.1.zip](E:/UQ/figma/deliverables/Gallery-Echoes-Mobile-Netlify-1.4.1.zip)，旧的 1.4.0 交付包保留历史。

1. 解压后，确保 `firmware/gallery_echoes_wifi/gallery_echoes_wifi.ino` 和 `mobile_assets.h` 在同一文件夹。
2. USB 数据线连接 Nano ESP32。在 Arduino IDE 选择 **Arduino ESP32 Boards by Arduino 2.x → Arduino Nano ESP32**、默认分区/引脚与正确端口。
3. 打开 .ino，先 Verify，再 **→ Upload**，等待完成。不能只复制 .ino 到新草稿，因为完整界面在 mobile_assets.h 中。
4. 保持板子供电；手机连 GalleryEchoes 后，`http://192.168.4.1/controller` 应显示 **Firmware 1.4.1**。仍显示 1.4.0 时，说明板上仍是旧版。

1.4.1 保留用户已确认正常的三路 `analogWrite` 控灯方式，增加明确的画廊返回入口，不自动连接或写灯。根地址仍有完整本地界面，`/controller` 保留七色直接测试页，`/set?hex=...`、`/off` 接口保持原样。

## 二维码与打印卡

- [mobile-qr/gallery-echoes-netlify-qr.png](E:/UQ/figma/mobile-qr/gallery-echoes-netlify-qr.png)：Netlify 公开主入口，平时扫码用这个。
- `mobile-qr/gallery-echoes-wifi-qr.png`：可选的 GalleryEchoes 入网码，仅实体灯操作时使用。
- `mobile-qr/gallery-echoes-local-control-qr.png`：可选本地调色面板码，仅已连设备热点时使用。
- `mobile-qr/scan-card.html`：双语打印卡，清晰区分在线浏览和可选实体灯操作。

普通 QR 不能保证一次扫描既切换 Wi-Fi 又打开另一个网页。这里的主码只打开在线原型，实体连接由用户按页面步骤主动完成。

## 验证与范围

全部 5 个 PNG 二维码已由独立 jsQR 1.4.0 解码并核对真实载荷，记录在 `mobile-qr/independent-decode.json`；生成器也核对了整数像素与完整白边。

Netlify 正式站点已发布。无登录公开访问及全部 **40 个静态文件**的内容和查询参数入口校验通过：39 个资源直接核对原始响应大小和 SHA-256；HTML 只移除本站 Netlify 注入的两段完整匹配的说明与徽章后，再与发布文件比对。证据在 [netlify-public-verification.json](E:/UQ/figma/deliverables/netlify-public-verification.json)。24 页在线界面、资源和交接参数另有本地软件检查；这不等于已完成手机实扫、页面点击或硬件联调。在线版使用同源静态资源预缓存，但是否已在某台手机缓存完成取决于浏览器及首次网络请求，不能保证首次离线可打开。

1.4.1 的真实 SDK 编译、完整链接和镜像容量以 `.firmware-build/compile-report.json` 当前报告为准；公网新版部署以 `deliverables/netlify-deployment.json` 和公开校验报告为准，不将旧版编译大小或旧 Deploy ID 视为新版证据。本次未替用户 USB 上传、手机实扫或实体灯现场联调。Echo 为本机记录，地图位置、NFC、振动和其他访客感想仍沿用原型的模拟范围。

后续更新继续部署到同一个 Netlify 站点，步骤和现有 Site ID 见 [NETLIFY-SETUP.md](E:/UQ/figma/NETLIFY-SETUP.md)，不需要重新创建网站。正式网址不变时也无需替换二维码。认证凭据不得写入源码。手机端视觉仍保留奶油白、衬线标题与粉彩主题。
